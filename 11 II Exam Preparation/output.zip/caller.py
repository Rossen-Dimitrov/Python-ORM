import os
import django
from django.db.models import Q

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Profile, Product, Order


def get_profiles(search_string=None) -> str:
    if search_string is None:
        return ""

    query = (Q(full_name__icontains=search_string) |
             Q(email__icontains=search_string) |
             Q(phone_number__icontains=search_string))

    profiles = Profile.objects.filter(query).order_by('full_name')

    all_profiles = []
    for p in profiles:
        all_profiles.append(
            f"Profile: {p.full_name},"
            f" email: {p.email},"
            f" phone number: {p.phone_number},"
            f" orders: {p.orders.count()}")

    return '\n'.join(all_profiles)


def get_loyal_profiles():
    profiles = Profile.objects.get_regular_customers()

    if not profiles:
        return ""

    return '\n'.join(f"Profile: {p.full_name}, orders: {p.count_orders}" for p in profiles)


def get_last_sold_products():
    last_order = Order.objects.prefetch_related('products').last()

    if last_order is None or not last_order.products.exists():
        return ""

    products = [p.name for p in last_order.products.all()]

    return f"Last sold products: {', '.join(products)}"



